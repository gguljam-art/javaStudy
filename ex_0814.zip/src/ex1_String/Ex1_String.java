package ex1_String;

import java.util.Scanner;

public class Ex1_String {
    public static void main(String[] args) {
     
        String s1 = "abc"; //암시적 객체생성
        String s2 = "abc"; 
        String s3 = new String("abc");//명시적 객체생성
        String s4 = new String("abc");

        //==은 객체간 비교에서는 주소값 비교를 한다.
        if(s1 == s3){
            System.out.println("주소가 같습니다.");
        }else{
            System.out.println("주소가 다릅니다.");
        }

        //String 클레스의 불변의 법칙
        String greet = "안녕";
        greet += "하세요";

        System.out.println(greet);

        Scanner sc = new Scanner(System.in);
        System.out.println("연산자: ");
        String op = sc.next();

        if(op.equals("+")){
            System.out.println("+연산할게요.");
        }
    }
}