package ex1_String;

public class Ex2_String {
    public static void main(String[] args) {
        String str = "Hong Gil Dong";
        int index = str.length();
        System.out.println("str의 길이: " + index);

        char c = 'o';
        index = str.indexOf(c);
        System.out.println("맨처음 문자 "+ c +"의 위치: "+(index+1));

        String s = "Gill";
        index = str.indexOf(s);
        System.out.println("맨처음 문자 "+ s +"의 위치: "+(index+1));

        char s2 = 'o';
        index = str.lastIndexOf(s2);
        System.out.println("맨처음 문자 "+ s2 +"의 위치: "+(index+1));
        System.out.println("6번째 문자:"+str.charAt(6));
        System.out.println(str.substring(1,6));

        String apple = "apple";
        if(apple.equals("apple")){
            System.out.println("사과");
        }

        if(apple.equalsIgnoreCase("Apple")){
            System.out.println("사과");
        }

        String password =" 1 234 ";
        String pwd2 = password.trim();
        System.out.println(password);
        System.out.println(pwd2);
        password = password.replaceAll(" ", "");
        System.out.println(password);

        //문자열로 작성된 숫자형태의 데이터를 실제 숫자로 변환
        String sn1 = "123";
        int n1 = Integer.parseInt(sn1);
        String sn2 = "333";
        int n2 = Integer.parseInt(sn2);

        System.out.printf("%s %s %d %d %d",sn1,sn2,n1,n2,(n1+n2));
        //기본 자료형의 Wrapper클래스
        //boolean -> Boolean
        //char -> Character
        //byte -> Byte
        //short -> Short
        //int -> Integer
        //long -> Long
        //float -> Float
        //double -> Double
    }
}
