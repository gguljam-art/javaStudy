package work;

import java.util.Scanner;

public class Ex_work {
    public static void main(String[] args) {

        int[] rArr = new int[3];
        int offset = 0;
        while(offset < 3){
            int r = (int)(Math.random() * 9) + 1;
            boolean b = true;
            for(int i = 0; i < rArr.length; i++){
                if(r == rArr[i]){
                    b = false;
                    break;
                };
            }

            if(b){
                rArr[offset] = r;
                offset ++;
            };
        }
        
        Scanner sc = new Scanner(System.in);
        boolean b = true;
        //equals사용을 위해 int[]형태를 String 형태로형변환
        String answer = "";
        for(int i : rArr){
            answer += i;
        }
        System.out.println(answer);

        w: while(b){
            System.out.print("세자리 수를 입력하세요(예: 123): ");
            String in = sc.next();
            //입력값 오류처리

            //3자리가 아닌 값을 입력해였을 때
            if(in.length() != 3){
                System.out.println("잘못 입력하였습니다.");
                continue w;
            }
            //숫자가 아닌 값을 입력하였을 때.
            for(int i = 0; i < in.length(); i++){
                if(in.charAt(i) < '0' || in.charAt(i) > '9'){
                    System.out.println("잘못 입력하였습니다.");
                    continue w;
                }
            }
            //같은값을 입력했을 때
            for(int i = 0; i < in.length(); i++){
                for(int j = i; j < in.length(); j++){
                    if(in.charAt(i)==in.charAt(j) && i!=j){
                        System.out.println("서로 다른 값을 입력하세요.");
                        continue w;
                    }
                }
            }

            //정답일 때 처리
            if(answer.equals(in)){
                System.out.println("정답입니다.");
                b = false;
                break;
            }

            //정답이 아닐 때
            int ball = 0;
            int strk = 0;

            for(int i = 0; i < in.length(); i++){
                //글자가 들어있는지 검사
                for(int j = 0; j < rArr.length; j++){
                    if(in.charAt(i) == answer.charAt(j)){
                        if(i == j) strk++;
                        else ball ++;
                        break;
                    }
                }
            }

            if(ball == 0 && strk == 0)
                System.out.println("아웃 입니다.");
            else
                System.out.printf("%d스트라이크 %d볼\n",strk, ball);
        }
    }
}
